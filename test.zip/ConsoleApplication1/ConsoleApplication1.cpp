﻿#include "pch.h"

using namespace System;

int main(array<System::String ^> ^args)
{
    telebird_dll::A::init(IntPtr(0));
    return 0;
}
